const ADMIN_EMAIL = "killerahmad305@gmail.com";
const waNumber = "923234842963";
let supabaseClient = null;
let currentFilter = "All";
let products = [];

function initSupabase() {
  if (!window.supabase || !window.SUPABASE_URL || !window.SUPABASE_ANON_KEY ||
      window.SUPABASE_URL.includes("PASTE_") || window.SUPABASE_ANON_KEY.includes("PASTE_")) return null;
  return window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
}
function safeText(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function waLink(p) {
  const message = `Assalam-o-Alaikum, I am interested in ${p.name}${p.price ? " (Price: " + p.price + ")" : ""}. Please share details.`;
  return `https://wa.me/${waNumber}?text=${encodeURIComponent(message)}`;
}
function renderProducts() {
  const grid = document.getElementById("product-grid");
  if (!grid) return;
  const visible = currentFilter === "All" ? products : products.filter(p => p.category === currentFilter);
  if (!visible.length) {
    grid.innerHTML = `<div class="empty">No products added yet. Please contact us on WhatsApp for available designs.</div>`;
    return;
  }
  grid.innerHTML = visible.map(p => `
    <article class="product-card">
      <div class="product-image">${p.image_url ? `<img src="${safeText(p.image_url)}" alt="${safeText(p.name)}" loading="lazy">` : `<span class="image-placeholder">AHMAD DOORS</span>`}</div>
      <div class="product-info">
        <span class="product-category">${safeText(p.category)}</span>
        <h3>${safeText(p.name)}</h3>
        <p>${safeText(p.description || "Contact us for details and availability.")}</p>
        <div class="product-bottom"><span class="price">${p.price ? safeText(p.price) : "Price on request"}</span><a class="order-small" href="${waLink(p)}" target="_blank" rel="noopener">ORDER ON WHATSAPP ↗</a></div>
      </div>
    </article>`).join("");
}
async function loadProducts() {
  supabaseClient = initSupabase();
  if (!supabaseClient) {
    products = [];
    renderProducts();
    return;
  }
  const { data, error } = await supabaseClient.from("products").select("*").eq("active", true).order("created_at", { ascending: false });
  if (error) {
    document.getElementById("product-grid").innerHTML = `<div class="empty">Products are temporarily unavailable. Please contact us on WhatsApp.</div>`;
    return;
  }
  products = data || [];
  renderProducts();
}
document.querySelectorAll("[data-filter]").forEach(el => el.addEventListener("click", () => {
  currentFilter = el.dataset.filter;
  document.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b.dataset.filter === currentFilter));
  renderProducts();
}));
const year = document.getElementById("year");
if (year) year.textContent = new Date().getFullYear();
loadProducts();
