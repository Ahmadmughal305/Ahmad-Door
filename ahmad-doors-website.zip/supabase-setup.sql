-- Run this SQL in Supabase Dashboard > SQL Editor.
-- Products are publicly readable. Only killerahmad305@gmail.com can add/edit/delete.
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null check (category in ('PVC Doors','Fibre Doors','Wooden Doors')),
  price text,
  description text,
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;

drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products"
on public.products for select
using (active = true or (auth.jwt() ->> 'email') = 'killerahmad305@gmail.com');

drop policy if exists "Owner can add products" on public.products;
create policy "Owner can add products"
on public.products for insert
with check ((auth.jwt() ->> 'email') = 'killerahmad305@gmail.com');

drop policy if exists "Owner can update products" on public.products;
create policy "Owner can update products"
on public.products for update
using ((auth.jwt() ->> 'email') = 'killerahmad305@gmail.com')
with check ((auth.jwt() ->> 'email') = 'killerahmad305@gmail.com');

drop policy if exists "Owner can delete products" on public.products;
create policy "Owner can delete products"
on public.products for delete
using ((auth.jwt() ->> 'email') = 'killerahmad305@gmail.com');

-- Create a PUBLIC storage bucket for product photos.
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do update set public = true;

drop policy if exists "Anyone can view product photos" on storage.objects;
create policy "Anyone can view product photos"
on storage.objects for select
using (bucket_id = 'product-images');

drop policy if exists "Owner can upload product photos" on storage.objects;
create policy "Owner can upload product photos"
on storage.objects for insert
with check (bucket_id = 'product-images' and (auth.jwt() ->> 'email') = 'killerahmad305@gmail.com');

drop policy if exists "Owner can update product photos" on storage.objects;
create policy "Owner can update product photos"
on storage.objects for update
using (bucket_id = 'product-images' and (auth.jwt() ->> 'email') = 'killerahmad305@gmail.com')
with check (bucket_id = 'product-images' and (auth.jwt() ->> 'email') = 'killerahmad305@gmail.com');

drop policy if exists "Owner can delete product photos" on storage.objects;
create policy "Owner can delete product photos"
on storage.objects for delete
using (bucket_id = 'product-images' and (auth.jwt() ->> 'email') = 'killerahmad305@gmail.com');
