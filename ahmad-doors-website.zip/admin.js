const OWNER = "killerahmad305@gmail.com";
const client = (window.supabase && window.SUPABASE_URL && window.SUPABASE_ANON_KEY &&
  !window.SUPABASE_URL.includes("PASTE_") && !window.SUPABASE_ANON_KEY.includes("PASTE_"))
  ? window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY) : null;
const $ = id => document.getElementById(id);
let editing = null;
function msg(id, text) { $(id).textContent = text; }
function escapeHTML(v) { return String(v ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function setLoggedIn(on) { $("login-panel").classList.toggle("hidden",on); $("dashboard").classList.toggle("hidden",!on); $("logout").classList.toggle("hidden",!on); }
async function checkSession() {
  if (!client) { msg("login-message","Setup needed: add your Supabase URL and publishable key in config.js."); return; }
  const {data:{session}} = await client.auth.getSession();
  const email = session?.user?.email?.toLowerCase();
  if (email === OWNER) { setLoggedIn(true); await listProducts(); } else { setLoggedIn(false); }
}
$("login").addEventListener("click", async () => {
  if (!client) return msg("login-message","Please configure config.js first.");
  msg("login-message","Signing in…");
  const {data,error} = await client.auth.signInWithPassword({email:$("email").value.trim(),password:$("password").value});
  if (error) return msg("login-message",error.message);
  if (data.user.email.toLowerCase() !== OWNER) { await client.auth.signOut(); return msg("login-message","This account is not authorized."); }
  msg("login-message","Login successful."); await checkSession();
});
$("logout").addEventListener("click", async()=>{await client.auth.signOut();setLoggedIn(false);});
async function listProducts() {
  const {data,error}=await client.from("products").select("*").order("created_at",{ascending:false});
  if(error){$("admin-products").textContent=error.message;return;}
  $("admin-products").innerHTML=(data||[]).map(p=>`<div class="admin-product"><div><b>${escapeHTML(p.name)}</b><small>${escapeHTML(p.category)} · ${escapeHTML(p.price||"Price on request")} · ${p.active?"Visible":"Hidden"}</small></div><div class="admin-actions"><button class="admin-btn secondary" data-edit="${p.id}">Edit</button><button class="admin-btn danger" data-delete="${p.id}">Delete</button></div></div>`).join("") || "No products yet.";
  $("admin-products").querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>editProduct(data.find(p=>p.id===b.dataset.edit)));
  $("admin-products").querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>deleteProduct(b.dataset.delete));
}
function editProduct(p){editing=p;$("product-id").value=p.id;$("name").value=p.name;$("category").value=p.category;$("price").value=p.price||"";$("description").value=p.description||"";$("form-title").textContent="Edit product";window.scrollTo({top:0,behavior:"smooth"});}
function clearForm(){editing=null;$("product-form").reset();$("product-id").value="";$("form-title").textContent="Add a product";msg("form-message","");}
$("cancel-edit").onclick=clearForm;
async function uploadPhoto(file){
  if(!file)return null;
  if(file.size>5*1024*1024)throw new Error("Photo must be smaller than 5 MB.");
  const ext=(file.name.split(".").pop()||"jpg").toLowerCase().replace(/[^a-z0-9]/g,"");
  const path=`${crypto.randomUUID()}.${ext}`;
  const {error}=await client.storage.from("product-images").upload(path,file,{upsert:false,contentType:file.type});
  if(error)throw error;
  const {data}=client.storage.from("product-images").getPublicUrl(path);
  return data.publicUrl;
}
$("product-form").addEventListener("submit",async e=>{
  e.preventDefault();msg("form-message","Saving…");
  const {data:{user}}=await client.auth.getUser();
  if(!user||user.email.toLowerCase()!==OWNER)return msg("form-message","Not authorized.");
  try{
    const photo=$("photo").files[0];let image_url=editing?.image_url||null;
    if(photo)image_url=await uploadPhoto(photo);
    const record={name:$("name").value.trim(),category:$("category").value,price:$("price").value.trim(),description:$("description").value.trim(),image_url,active:true};
    const result=editing?await client.from("products").update(record).eq("id",editing.id):await client.from("products").insert(record);
    if(result.error)throw result.error;
    clearForm();msg("form-message","Product saved.");await listProducts();
  }catch(err){msg("form-message",err.message||"Could not save product.");}
});
async function deleteProduct(id){if(!confirm("Delete this product?"))return;const {error}=await client.from("products").delete().eq("id",id);if(error)alert(error.message);else await listProducts();}
checkSession();
